// Copyright (c) 2025, vms and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Evaluation Form", {
// 	refresh(frm) {

// 	},
// });
